$sites = @(
    "https://google.com",
    "https://www.microsoft.com",
    "https://github.com",
    "https://packages.nzsuperfund.co.nz/",
	"https://secretserver.nzsuperfund.co.nz:8081/",
	"https://nzsuperfund.sharepoint.com/"	
)

# Number of iterations
$runs = 10

# Process each website
$results = foreach ($url in $sites) {
    Write-Host "Testing $url..." -ForegroundColor Cyan
    $times = @()

    for ($i = 1; $i -le $runs; $i++) {
        try {
            # Measure-Command tracks execution time precisely
            $elapsed = Measure-Command {
                # -UseBasicParsing prevents loading Internet Explorer engine
                # -TimeoutSec ensures a stuck site won't hang your script
                $null = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 10
            }
            $times += $elapsed.TotalMilliseconds
        }
        catch {
            Write-Host "  Run $i failed: $_" -ForegroundColor Red
        }
    }

    # Calculate average if there are successful runs
    if ($times.Count -gt 0) {
        $averageTime = ($times | Measure-Object -Average).Average
        [PSCustomObject]@{
            Website     = $url
            TotalRuns   = "$($times.Count)/$runs"
            AverageMs   = [Math]::Round($averageTime, 2)
        }
    } else {
        [PSCustomObject]@{
            Website     = $url
            TotalRuns   = "0/$runs"
            AverageMs   = "Failed"
        }
    }
}

# Output the results in a clean table format
$results | Format-Table -AutoSize